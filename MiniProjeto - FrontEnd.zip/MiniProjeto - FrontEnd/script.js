// Função chamada ao clicar em "Cadastrar" (pág. 20 e 22)
function cadastrarAluno() {
  let rgm = document.getElementById("rgm").value;
  let nome = document.getElementById("nome").value;
  let n1 = parseFloat(document.getElementById("nota1").value);
  let n2 = parseFloat(document.getElementById("nota2").value);
  let n3 = parseFloat(document.getElementById("nota3").value);

  // Validação simples dos campos
  if (!rgm || !nome || isNaN(n1) || isNaN(n2) || isNaN(n3)) {
    alert("Por favor, preencha todos os campos corretamente.");
    return;
  }

  // Identifica o próximo número de ordem baseado no item 'qtd' salvo
  let qtd = localStorage.getItem("qtd");
  if (qtd === null) {
    qtd = 1;
  } else {
    qtd = parseInt(qtd) + 1;
  }

  // Grava cada campo no localStorage conforme orientado na pág. 22
  localStorage.setItem("rgm" + qtd, rgm);
  localStorage.setItem("nome" + qtd, nome);
  localStorage.setItem("n1" + qtd, n1);
  localStorage.setItem("n2" + qtd, n2);
  localStorage.setItem("n3" + qtd, n3);
  localStorage.setItem("qtd", qtd);

  alert("Aluno cadastrado com sucesso!");
  limparCampos();
}

// Função para limpar os inputs após o cadastro (pág. 20)
function limparCampos() {
  document.getElementById("rgm").value = "";
  document.getElementById("nome").value = "";
  document.getElementById("nota1").value = "";
  document.getElementById("nota2").value = "";
  document.getElementById("nota3").value = "";
}

// Função chamada ao clicar em "Exibir" (pág. 20 e 21)
function exibirAlunos() {
  let qtd = localStorage.getItem("qtd");

  if (!qtd || parseInt(qtd) === 0) {
    alert("Nenhum aluno cadastrado no momento!");
    document.getElementById("areaTabela").style.display = "none";
    return;
  }

  let corpoTabela = document.getElementById("corpoTabela");
  corpoTabela.innerHTML = ""; // Limpa a tabela antes de preenchê-la

  qtd = parseInt(qtd);

  for (let i = 1; i <= qtd; i++) {
    let rgm = localStorage.getItem("rgm" + i);

    // Garante que o registro ainda existe (caso tenha sido removido individualmente)
    if (rgm !== null) {
      let nome = localStorage.getItem("nome" + i);
      let n1 = parseFloat(localStorage.getItem("n1" + i));
      let n2 = parseFloat(localStorage.getItem("n2" + i));
      let n3 = parseFloat(localStorage.getItem("n3" + i));

      // Cálculo da nota final (soma das notas)
      let notaFinal = n1 + n2 + n3;
      let conceito = "";
      let classeCor = "";

      // Regras do Miniprojeto (pág. 20):
      // Aprovado: soma >= 6 (Verde)
      // Reprovado: soma <= 1.5 (Vermelho)
      // AF: soma entre 1.5 e 6 (Laranja)
      if (notaFinal >= 6) {
        conceito = "Aprovado";
        classeCor = "aprovado";
      } else if (notaFinal <= 1.5) {
        conceito = "Reprovado";
        classeCor = "reprovado";
      } else {
        conceito = "AF";
        classeCor = "af";
      }

      // Monta a linha (tr) da tabela em HTML
      let linha = `<tr>
        <td>${rgm}</td>
        <td>${nome}</td>
        <td>${notaFinal.toFixed(2)}</td>
        <td class="${classeCor}">${conceito}</td>
      </tr>`;

      corpoTabela.innerHTML += linha;
    }
  }

  // Torna a área da tabela visível
  document.getElementById("areaTabela").style.display = "block";
}

// Função chamada ao clicar em "Apagar" (pág. 20)
function apagarDados() {
  // Caixa de confirmação antes de apagar (pág. 20)
  let confirmacao = confirm("Deseja realmente apagar todos os registros salvos?");
  if (confirmacao) {
    localStorage.clear();
    document.getElementById("areaTabela").style.display = "none";
    alert("Todos os dados foram apagados com sucesso!");
  }
}

// Função chamada ao clicar em "Autores" (pág. 21)
function mostrarAutores() {
  alert("Autores:\nLorenzo Ferreira Rodrigues\nGuilherme Sales Da Silva\nAndrey Oliveira Da Silva");
}